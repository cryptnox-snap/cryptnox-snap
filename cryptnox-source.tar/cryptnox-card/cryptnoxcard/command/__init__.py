# -*- coding: utf-8 -*-
"""
Module to work with commands given by the user in a command line
"""
from .factory import Factory
